/*
Navicat MySQL Data Transfer

Source Server         : 192.168.137.177_3306
Source Server Version : 50619
Source Host           : 192.168.137.177:3306
Source Database       : discuz_first

Target Server Type    : MYSQL
Target Server Version : 50619
File Encoding         : 65001

Date: 2015-05-22 17:15:13
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `pre_ucenter_member_tableid`
-- ----------------------------
DROP TABLE IF EXISTS `pre_ucenter_member_tableid`;
CREATE TABLE `pre_ucenter_member_tableid` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`uid`)
) ENGINE=Innodb  DEFAULT CHARSET=utf8;

