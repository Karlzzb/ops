 ALTER TABLE pre_s8cash_log CHANGE lixi fee float;
 delete from pre_common_plugin where name = 'Sex8';