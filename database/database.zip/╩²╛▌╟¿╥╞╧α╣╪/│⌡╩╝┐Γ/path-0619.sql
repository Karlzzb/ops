update pre_common_nav set `available` = 1 where `id` = 3;
ALTER TABLE pre_s8cash_log CHANGE lixi fee float;