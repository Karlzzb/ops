#define REDIS_GIT_SHA1 "447add3a"
#define REDIS_GIT_DIRTY "0"
#define REDIS_BUILD_ID "discuz-redis-1432287009"
