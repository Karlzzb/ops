##How To Build
npm install

npm install -g bower

bower install

./build.sh
