#!/bin/bash

JMX_PORT="$1"
JAVA="/opt/jdk/jre/bin/java"
JAR="/home/zabbix/agent_bin/cmdline-jmxclient-0.10.3.jar"



if [ "$2" == "java.lang:type=Threading" -o "$2" == "java.lang:type=ClassLoading" -o "$2" == "Catalina:context=/video_gs,host=localhost,type=Manager" ]; then
    "$JAVA" -jar "$JAR" - 127.0.0.1:"$JMX_PORT" "$2" "$3" 2>&1 | awk -F: '/'$3'/ {print $NF}' 
    exit 0
fi

if [ "$2" == "java.lang:type=Memory" ]; then
    if [ $# -ne 4 ]; then
        echo "-0.0001"
        exit 1
    fi
    "$JAVA" -jar "$JAR" - 127.0.0.1:"$JMX_PORT" "$2" "$3" 2>&1 | awk -F: '/'$4'/ {print $NF}' 
fi
