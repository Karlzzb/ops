#!/bin/bash

if [ ! -x /usr/sbin/arcconf ]; then
    echo "0"
    exit 1
fi

case "$1" in 
    controller_status)
        C1=$(sudo /usr/sbin/arcconf GETCONFIG 1 2>/dev/null | grep -w Optimal | wc -l)
        C2=$(sudo /usr/sbin/arcconf GETCONFIG 2 2>/dev/null | grep -w Optimal | wc -l)
        echo  $(( C1 + C2 )) ;; 
    disk_online)
        D1=$(sudo /usr/sbin/arcconf GETCONFIG 1 2>/dev/null | grep -w Online | wc -l)
        D2=$(sudo /usr/sbin/arcconf GETCONFIG 2 2>/dev/null | grep -w Online | wc -l)
        echo  $(( D1 + D2 )) ;; 
    *)              echo "-1" ;;
esac
