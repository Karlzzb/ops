#!/bin/bash
# lvs active connections

case "$1" in
    50.117.12.100)
        /usr/bin/sudo /sbin/ipvsadm | sed -n '/50.117.12.100/,/50.117.12.101/p' | awk '/Route/ {sum+=$5} END {print sum}'
        ;;
    50.117.12.101)
        /usr/bin/sudo /sbin/ipvsadm | sed -n '/50.117.12.101/,/50.117.12.102/p' | awk '/Route/ {sum+=$5} END {print sum}'
        ;;
    50.117.12.102)
        /usr/bin/sudo /sbin/ipvsadm | sed -n '/50.117.12.102/,$p' | awk '/Route/ {sum+=$5} END {print sum}'
        ;;
    *)
        echo "-1" ;;
esac
