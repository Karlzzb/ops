<?php

if('cli' != php_sapi_name() ){
    die("run error");
}

if(!file_exists("config.php")){
    die("can't include config file");
}
else{
    include "config.php";
}

if(!file_exists("uid.php")){
    die("can't include uid.php");
}
else{
    include "uid.php";
}

$is_update = 0;
if($argc >= 2){
    $is_update = intval($argv[1]);
    $is_update = $is_update == 1? 1: 0;
}

$conn = mysql_connect($mysql_ip,$mysql_user,$mysql_pwd);
if(!$conn){
	die("connect db error:".mysql_error());
}

mysql_select_db($mysql_db);
mysql_query("set names utf8");
$uid_str = implode(',',$uid);
$redis = new Redis();
$redis->connect($redis_ip, $redis_port);

$sql = "select * from video.video_user where uid in (".$uid_str.")";
$query = mysql_query($sql);
echo "update to reids:$is_update\n";
while($row = mysql_fetch_assoc($query)){
	if($row['uid']>=1){
        if($is_update)
	    	$redis->hMset('huser_info:'.$row['uid'], $row);
        else
            var_dump($row);
	}
}
mysql_close($conn);
