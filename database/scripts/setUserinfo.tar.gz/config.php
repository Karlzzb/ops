<?php
$mysql_ip = '172.16.30.14:3366';
$mysql_user = 'videousr';
$mysql_pwd = 'dsdffss06d925114fdfa3b26e339bda';
$mysql_db = 'video';
$redis_ip = 'caegi-v-redis-vip';
$redis_port = 6379;
