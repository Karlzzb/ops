<?php

$month = $argv[1];

// 配置文件
require_once 'config.php';
// mysql , redis连接
require_once 'db.php';

$db_mysqli = new db_mysqli();
$link_dx = $db_mysqli->connect();
$time = strtotime('-'.$month.' month');
$sql = "select count(1),tid from pre_forum_thread where dateline> $time order by tid limit 1";
$result = mysqli_query($link_dx,$sql);
$row = mysqli_fetch_assoc($result);
var_dump($row);