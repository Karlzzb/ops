<?php

$config = array(
    // 源数据数据库
    'mysql'=>array(
        'db_host'=>'caegi-b-mysql-vip',
        'db_user'=>'data_trans',
        'db_pwd'=>'7451831f8c476ddf8e3',
        'db_name'=>'discuz_db',
        'db_port'=>'6980',
        'db_prfix'=>'pre_'
    ),
    /*'mysql'=>array(
        'db_host'=>'127.0.0.1',
        'db_user'=>'root',
        'db_pwd'=>'',
        'db_name'=>'ultrax',
        'db_port'=>'3306',
        'db_prfix'=>'pre_'
    ),*/

    // 用户信息主库
    'redis_db1' =>array(
        'host'=>'caegi-b-redis01',
        'port'=>'19000'
    ),
    // 主题帖子库1
   'redis_db2' =>array(
        'host'=>'caegi-b-redis01',
        'port'=>'19000'
    ),
    // 主题帖子库2
   'redis_db3' =>array(
        'host'=>'caegi-b-redis01',
        'port'=>'19000'
    ),
    // 主题转换的时间节点，时间节点以后的帖子才预热
    'forum_start_time'=> '4700160', // 发布的时间点之后的tid 可以从getThreadId.php 获取时间点的tid 
    'thread_start_time'=> '0', // 主题从多少tid之后开始压入
    'user_time'=>3, //最近登陆的用户的时间几个月
    'user_ex_time'=>15552000 // 用户过期的时间

);
