<?php


class db_mysqli
{
    public function __construct()
    {
        global $config;
        $mysql = $config['mysql'];
// mysql 数据库连接
        $link_dx = mysqli_connect($mysql['db_host'], $mysql['db_user'], $mysql['db_pwd'], $mysql['db_name'], $mysql['db_port']) or die("Connect " . $mysql['db_host'] . "is failure");
        mysqli_query($link_dx, "set names utf8");
        $this->link_dx= $link_dx;
    }

    public function connect()
    {
        return $this->link_dx;
    }


}
