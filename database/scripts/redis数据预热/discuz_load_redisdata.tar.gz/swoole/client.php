<?php

if(!isset($argv[1])){
    echo '   【error】:请输入参数！';
    help();
    exit;
}

$script = $argv[1];

// 帮助参数
if($script == '-h' || $script == 'help'){
    help();
    exit;
}

/**
 * 所有的keys key 和脚本的名字相同，每个key对应一个脚本儿处理
 * value 为对应的写入redis的key前缀
 */
$keys = array(
    // 用户主表
    'member' => 'dz_common_member_',
    // 用户详细信息
    'member_profile' => 'dz_common_member_profile_',
    // 用户统计
    'member_count' => 'dz_common_member_count_',
    // 用户状态
    'member_status' => 'dz_common_member_status_',
    // 用户家园字段详细信息
    'member_field_home' => 'dz_common_member_field_home_',

    // 主题信息
    'forum_thread' => 'dz_forum_thread_',

    // 帖子信息
    'forum_post' => 'dz_forum_post_tid_',

    // 用户名和邮箱的hash值
    'hash_user'=>'',

    // 主题的有序集合 用于主题列表翻页时的数据处理
    'thread_set'=>''
);

if (!isset($keys[$script])) {
    echo '   【error】:参数错误啦！！！！！';
    help();
    exit;
}


$data = array();
$data['script_name'] = $script;
$cli = new swoole_client(SWOOLE_TCP );
$cli ->connect('127.0.0.1' , 9502);
echo "<pre>";
var_dump($data);
$cli -> send(serialize($data));








function help()
{
    $str= <<<Eof

    环境要求： 必须支持swoole扩展


    -h | help :                帮助选项;

    【用户】
    member_status <预先> :      预热用户的状态信息 "在预热用户其他信息前下要预热状态"
    member :                    预热用户表的'主表'的信息
    member_count :              预热用户的积分等统计信息
    member_profile :            预热用户的详细信息
    member_field_home :         预热用户的个人中心的信息

    【用户hash】
    hash_user                   用户名和用户的邮箱的hash表 主要用于登陆注册 持久化的

    【帖子】
    forum_thread :              预热主题信息
    forum_post :                预热帖子信息,每十条一个key,最近多少月的数据请配置起始tid

    【主题列表】
    thread_set                  主题列表的有序集合 用户提高列表的翻页性能问题


! 先启动server脚本 执行server.php；
  目录下log.txt 中记录了跑的状态
  hash_user 日志为 hash_user.txt

*注意：1、跑forum_thread 或 forum_post 时，如需要跑某个时间点之后的主题和帖子，请先执行
      目录下的 “getThreadId.php 6 ”获取6个月之内的主题和帖子的tid，并配置到config.php
      中：forum_start_time、thread_start_time两项配置，大于此tid的才会预热到redis中。
      2、在跑用户时必须在跑完member_status后才能跑其他的数据


Eof;
    echo $str;
}
