<?php
require_once 'base.php';

class thread_set extends base
{
    // 数据库表名
    protected $table = 'forum_thread';

    public function doSet($fid)
    {
        global $config;

        $db_mysqli = new db_mysqli();
        $link_dx = $db_mysqli->connect();

        $redis = $this->getRedis('redis_db1');
        $count = 0;// 计数
        $num = 5000;
        $f = implode(',', $fid);
        while (1) {
            // 先取出首帖
            $start = $count * $num + 1;
            $sql = 'SELECT tid,fid, replies, dateline, lastpost, views,special,displayorder FROM ' . $config['mysql']['db_prfix'] . $this->table . ' WHERE fid in  (' . $f . ') AND displayorder in (0,1)  ORDER BY lastpost DESC LIMIT ' . $start . ',' . $num;
            $result = mysqli_query($link_dx, $sql);
            if (!$result->num_rows) {
                break;
            }
            while ($t = mysqli_fetch_assoc($result)) {

                $fid = $t['fid'];
                if ($t['displayorder'] == 0) {
                    $redis->zAdd($fid . '-replies', $t['replies'], $t['tid']);
                    $redis->zAdd($fid . '-dateline', $t['dateline'], $t['tid']);
                    $redis->zAdd($fid . '-lastpost', $t['lastpost'], $t['tid']);
                    $redis->zAdd($fid . '-views', $t['views'], $t['tid']);

                    // 特殊主题
                    if ($t['special'] != 0) {
                        $redis->zAdd($fid . '-replies-' . $t['special'], $t['replies'], $t['tid']);
                        $redis->zAdd($fid . '-dateline-' . $t['special'], $t['dateline'], $t['tid']);
                        $redis->zAdd($fid . '-lastpost-' . $t['special'], $t['lastpost'], $t['tid']);
                        $redis->zAdd($fid . '-views-' . $t['special'], $t['views'], $t['tid']);
                    }
                } else {
                    $redis->zAdd($fid . '-top', $t['dateline'], $t['tid']);
                }
            }
            // 写入redis
            $count++;
        }

        return date('Y-m-d H:i:s') . ':forum_set fid' . $f ." 板块集合列表数据, 导入完成！\n";
    }
}
