<?php
require_once 'base.php';

class member_field_home extends base
{
    protected $table = 'common_member_field_home_';
    protected $redis_key = 'discuz_common_member_field_home_';

}