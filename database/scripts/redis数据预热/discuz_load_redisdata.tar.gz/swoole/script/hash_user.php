<?php
require_once 'base.php';

class hash_user extends base
{
    protected $table = 'common_member_';

    /**
     *
     * @param $i 第多少表
     */
    public function into($i)
    {
        global $config;
        $db_mysqli = new db_mysqli();
        $link_dx = $db_mysqli->connect();


        $count = 0;// 计数
        $num = 5000;
        while (1) {
            $start = $num * $count;
            $sql = 'select uid,username,email from ' . $config['mysql']['db_prfix'] . $this->table . $i . ' limit ' . $start . ',' . $num;
            try {

                file_put_contents('hash_user.log',date('Y-m-d H:i:s')."  ".$sql ."\n",FILE_APPEND);
                $result = mysqli_query($link_dx, $sql);
                if (!$result || !$result->num_rows) {
                    break;
                }
                while ($row = mysqli_fetch_assoc($result)) {
                    $username = md5($row['username']);
                    $email = md5($row['email']);
                    $uid = $row['uid'];

                    // 写入redis
                    $this->hWrite('redis_db1', substr($username, 0, 5), $username, $uid);
                    $this->hWrite('redis_db1', substr($email, 0, 5), $email, $uid);
                }
            } catch (ErrorException $e) {
                //var_dump($e->getMessage());
            }
            $count++;
            file_put_contents('c.txt', $count . "\n", FILE_APPEND);
        }

        // 返回给进程中做处理
        return date('Y-m-d H:i:s') . ':' . $this->table . $i . "表用户名和邮箱hash写入数据, 导入完成！\n";
    }
}
