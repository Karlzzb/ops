<?php
require_once 'base.php';

class thread_set extends base
{
    public function doTop()
    {
        global $config;
        $db_mysqli = new db_mysqli();
        $link_dx = $db_mysqli->connect();
        $redis = $this->getRedis('redis_db1');
        ///增加一级置顶处理
        $sql = "SELECT tid,lastpost FROM ".$config['mysql']['db_prfix']."_forum_thread WHERE `displayorder` IN('2','3','4')  ORDER BY displayorder DESC, lastpost DESC";
        $query = mysqli_query($link_dx,$sql);
        while ($t = mysqli_fetch_assoc($query)) {
            $redis->zAdd('g-top', $t['lastpost'], $t['tid']);
        }
    }
}