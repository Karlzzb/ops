<?php
require_once 'base.php';

class member extends base
{
    protected $table = 'common_member_';
    protected $redis_key = 'discuz_common_member_';


}