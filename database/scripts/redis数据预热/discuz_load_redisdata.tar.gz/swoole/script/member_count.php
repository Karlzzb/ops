<?php
require_once 'base.php';

class member_count extends base
{
    protected $table = 'common_member_count_';
    protected $redis_key = 'discuz_common_member_count_';

}