<?php
require_once 'base.php';

class member_profile extends base
{
    protected $table = 'common_member_profile_';
    protected $redis_key = 'discuz_common_member_profile_';
}