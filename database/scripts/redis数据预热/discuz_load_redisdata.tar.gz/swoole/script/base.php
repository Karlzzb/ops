<?php

//require_once 'RedisClientSwoole.php';
class base
{
    protected $redis_db = array();

    public function __construct()
    {

    }

    protected function getRedis($db_name)
    {
        global $config;
//        if(isset($this->redis_db[$db_name]) && $this->redis_db[$db_name]->is)

        $redis_db1 = new Redis();
        $redis_db1->pconnect($config[$db_name]['host'], $config[$db_name]['port']);
        return $redis_db1;

//        $this->redis_db['redis_db1'] = $redis_db1;
//
//        $redis_db2 = new Redis();
//        $redis_db2->connect($config['redis_db2']['host'], $config['redis_db2']['port']);
//        $this->redis_db['redis_db2'] = $redis_db2;
//
//        $redis_db3 = new Redis();
//        $redis_db3->connect($config['redis_db3']['host'], $config['redis_db3']['port']);
//        $this->redis_db['redis_db3'] = $redis_db3;
    }


    /**
     * 向redis写入数据
     *
     * @param $redis_db 选用的redis的服务器
     * @param array $data 插入的值
     * @return mixed
     */
    protected function write($redis_db, $data)
    {
        if (empty($data)) {
            return;
        }
//        $redis = $this->redis_db[$redis_db];
        $redis = $this->getRedis($redis_db);
        try {
            $res = $redis->Mset($data);
            if (!$res) {
                file_put_contents('redis_fail.txt', $res, FILE_APPEND);
            }
        } catch (RedisException $e) {
            file_put_contents('redis_error.txt', $e->getMessage(), FILE_APPEND);
        }

    }


    /**
     * 向redis写入数据
     *
     * @param $redis_db 选用的redis的服务器
     * @param array $data 插入的值
     * @return mixed
     */
    protected function hWrite($redis_db, $key,$field,$value)
    {
        if (empty($value)) {
            return;
        }
        $redis = $this->getRedis($redis_db);
        try {
            $redis->hSet($key,$field,$value);
        } catch (RedisException $e) {
            file_put_contents('redis_error.txt', $e->getMessage(), FILE_APPEND);
        }

    }

    protected function writeEx($redis_db, $key, $data, $ttl)
    {
        $redis = $this->getRedis($redis_db);
        try {
            $res = $redis->setex($key, $ttl, $data);
            if (!$res) {
                file_put_contents('redis_fail.txt', $res, FILE_APPEND);
            }
        } catch (RedisException $e) {
            file_put_contents('redis_error.txt', $e->getMessage(), FILE_APPEND);
        }
    }


    /**
     *
     * @param $i 第多少表
     */
    public function into($i)
    {
        global $config;
        global $keys;
        $db_mysqli = new db_mysqli();
        $link_dx = $db_mysqli->connect();
        $ttl = $config['user_ex_time'];
        $count = 0;// 计数

        while (1) {
            $uid = $this->getRedis('redis_db1')->get('visit_' . $i . '_' . $count);
            $sql = 'select * from ' . $config['mysql']['db_prfix'] . $this->table . $i . ' where uid in (' . $uid . ')';
            try {
                $result = mysqli_query($link_dx, $sql);
                if (!$result || !$result->num_rows) {
                    break;
                }
                while ($row = mysqli_fetch_assoc($result)) {
                    // 串行化
                    //$data = json_encode($row);
                    $data = serialize($row);
                    // 写入redis
                    $this->writeEx('redis_db1', $this->redis_key . $row['uid'], $data, $ttl);
                }
            } catch (mysqli_sql_exception $e) {
                var_dump($e->getMessage());
            }
            $count++;
        }

        // 返回给进程中做处理
        return date('Y-m-d H:i:s') . ':' . $this->table . $i . "表数据, 导入完成！\n";
    }


}
