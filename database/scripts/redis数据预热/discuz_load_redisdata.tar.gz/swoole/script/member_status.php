<?php
require_once 'base.php';

class member_status extends base
{
    protected $table = 'common_member_status_';

    public function into($i)
    {
        global $config;
        global $keys;
        $db_mysqli = new db_mysqli();
        $link_dx = $db_mysqli->connect();

        $user_time = strtotime('-' . $config['user_time'] . ' month');
        $ttl = $config['user_ex_time'];


        $count = 0;// 计数
        $num = 5000;
        while (1) {
            // 先取出首帖
            $uid = array();
            $start = $count * $num + 1;
            $sql = 'select * from ' . $config['mysql']['db_prfix'] . $this->table . $i . ' where lastvisit>' . $user_time . ' limit ' . $start . ',' . $num;
            $result = mysqli_query($link_dx, $sql);
            if (!$result->num_rows) {
                break;
            }
            $array = array();
            while ($row = mysqli_fetch_assoc($result)) {
                $uid[] = $row['uid'];
                // 串行化
                $data = json_encode($row);
                $array[] = $data;
                // 写入redis
                $this->writeEx('redis_db1', $keys['member_status'] . $row['uid'],$data,$ttl);
            }
            // 写入最近访问的用户，用于其他的进程使用的uid
            $this->getRedis('redis_db1')->set('visit_' . $i.'_'.$count, implode(',',$uid));
            $count++;
        }


        // 返回给进程中做处理
        return date('Y-m-d H:i:s') . ':common_member_status_' . $i . "表数据, 导入完成！\n";
    }
}
