<?php
require_once 'base.php';

class forum_thread extends base
{
    // 数据库表名
    protected $table = 'forum_thread';

    public function into($open, $end)
    {
        global $config;

        global $keys;
        $db_mysqli = new db_mysqli();
        $link_dx = $db_mysqli->connect();

        $count = 0;// 计数
        $num = 1000;
        $open = ($config['forum_start_time'] + $open);
        $end = $config['forum_start_time'] + $end;
        while (1) {
            // 先取出首帖
            $start = $count * $num + 1;

            $sql = 'select * from ' . $config['mysql']['db_prfix'] . $this->table . ' where tid > ' . $open . ' and tid < ' . $end . ' limit ' . $start . ',' . $num;
            $result = mysqli_query($link_dx, $sql);
            if (!$result->num_rows) {
                break;
            }
            $into_data_2 = array();
            $into_data_3 = array();
            while ($row = mysqli_fetch_assoc($result)) {
                // 串行化
                $data = serialize($row);

                // 根据tid 取余数 写入不同的redis服务器
                if ($row['tid'] % 2 == 0) {
                    $into_data_2[$keys['forum_thread'] . $row['tid']] = $data;
                } else {
                    $into_data_3[$keys['forum_thread'] . $row['tid']] = $data;
                }
            }
            // 写入redis
            $this->write('redis_db2', $into_data_2);
            $this->write('redis_db3', $into_data_3);
            $count++;
        }

        return date('Y-m-d H:i:s') . ':forum_thread tid' . $open .'---'.$end . "数据, 导入完成！\n";
    }
}