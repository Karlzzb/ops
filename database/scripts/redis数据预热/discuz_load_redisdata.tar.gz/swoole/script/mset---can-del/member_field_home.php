<?php
require_once 'base.php';

class member_field_home extends base
{
    protected $table = 'common_member_field_home_';

    public function into($i)
    {
        global $config;
        global $keys;

        $db_mysqli = new db_mysqli();
        $link_dx = $db_mysqli->connect();
        // 50张表
        $count = 0;// 计数
        $num = 5000;
        while (1) {
            // 先取出首帖
            $start = $count * $num + 1;
            $sql = 'select * from ' . $config['mysql']['db_prfix'] . $this->table . $i . ' limit ' . $start . ',' . $num;
            $result = mysqli_query($link_dx, $sql);
            if (!$result->num_rows) {
                break;
            }
            $array = array();
            while ($row = mysqli_fetch_assoc($result)) {
                // 串行化
                $data = serialize($row);
                $array[$keys['member_field_home'] . $row['uid']] = $data;
            }
            // 写入redis
            $this->write('redis_db1', $array);
            $count++;
        }

        // 返回给进程中做处理
        return date('Y-m-d H:i:s') . ':common_member_field_home_' . $i . "表数据, 导入完成！\n";
    }
}