<?php

class base
{

    /**
     * 向redis写入数据
     *
     * @param $redis_db 选用的redis的服务器
     * @param array $data 插入的值
     * @return mixed
     */
    protected  function write($redis_db,$data)
    {
        if(empty($data)){
            return;
        }
        global $config;
        $redis_config = $config[$redis_db]; // 根据传入的名字选择对应的redis服务器
        try{
            $redis = new Redis();
            $redis->connect($redis_config['host'], $redis_config['port']);
            $res = $redis->mset($data);
            if(!$res){
                file_put_contents('redis_fail.txt',$res,FILE_APPEND);
            }
        }catch (RedisException $e){
            file_put_contents('redis_error.txt',$e->getMessage(),FILE_APPEND);
        }


    }
}
