<?php
require_once 'base.php';

class member_count extends base
{
    protected $table = 'common_member_count_';

    public function into($i)
    {
        global $config;
        global $keys;
        $db_mysqli = new db_mysqli();
        $link_dx = $db_mysqli->connect();
        // 50张表
        $count = 0;// 计数
        $num = 5000;
        while (1) {
            // 先取出首帖
            $start = $count * $num + 1;
            $sql = 'select * from ' . $config['mysql']['db_prfix'] . $this->table . $i . ' limit ' . $start . ',' . $num;
            $result = mysqli_query($link_dx, $sql);
            if (!$result->num_rows) {
                break;
            }
            $array = array();
            while ($row = mysqli_fetch_assoc($result)) {
                // 串行化
                $data = serialize($row);
                $mod = $row['uid']%100000;//uid取余写入不同的段儿中
                $hash_key = 'member_count:'.$mod;// 拼接用户hash段
                $array[$hash_key][$row['uid']] = $data;
            }
            // 写入redis $num条同时写入
            $this->write('redis_db1', $array);
            $count++;
        }
        // 返回给进程中做处理
        return date('Y-m-d H:i:s') . ':common_member_count_' . $i . "表数据, 导入完成！\n";
    }
}