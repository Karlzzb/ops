<?php

class base
{
    protected $redis_db = array();

    public function __construct()
    {

    }

    protected function getRedis($db_name)
    {
        global $config;
//        if(isset($this->redis_db[$db_name]) && $this->redis_db[$db_name]->is)

        $redis_db1 = new Redis();
        $redis_db1->connect($config[$db_name]['host'], $config[$db_name]['port']);
        return $redis_db1;

//        $this->redis_db['redis_db1'] = $redis_db1;
//
//        $redis_db2 = new Redis();
//        $redis_db2->connect($config['redis_db2']['host'], $config['redis_db2']['port']);
//        $this->redis_db['redis_db2'] = $redis_db2;
//
//        $redis_db3 = new Redis();
//        $redis_db3->connect($config['redis_db3']['host'], $config['redis_db3']['port']);
//        $this->redis_db['redis_db3'] = $redis_db3;
    }


    /**
     * 向redis写入数据
     *
     * @param $redis_db 选用的redis的服务器
     * @param array $data 插入的值
     * @return mixed
     */
    protected function write($redis_db, $data)
    {
        if (empty($data)) {
            return;
        }
//        $redis = $this->redis_db[$redis_db];
        $redis = $this->getRedis($redis_db);
        foreach ($data as $key => $value) {
            try {
                $res = $redis->hMset($key, $value);
                if (!$res) {
                    file_put_contents('redis_fail.txt', $res, FILE_APPEND);
                }
            } catch (RedisException $e) {
                file_put_contents('redis_error.txt', $e->getMessage(), FILE_APPEND);
            }
        }

    }
}
