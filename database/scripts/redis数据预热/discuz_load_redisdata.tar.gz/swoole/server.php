<?php

// 配置文件
require_once 'config.php';
// mysql , redis连接
require_once 'db.php';

// 脚本 php into.php  member  1   1000
// 要灌数据的key脚本名字

/**
 * 所有的keys key 和脚本的名字相同，每个key对应一个脚本儿处理
 * value 为对应的写入redis的key前缀
 */
$keys = array(
    // 用户主表
    'member' => 'discuz_common_member_',
    // 用户详细信息
    'member_profile' => 'discuz_common_member_profile_',
    // 用户统计
    'member_count' => 'discuz_common_member_count_',
    // 用户状态
    'member_status' => 'discuz_common_member_status_',
    // 用户家园字段详细信息
    'member_field_home' => 'discuz_common_member_field_home_',

    // 主题信息
    'forum_thread' => 'dz_forum_thread_',
    // 帖子信息
    'forum_post' => 'dz_forum_post_tid_',
    'hash_user' => '',
    'thread_set'=>''
);


class hotServer
{
    protected static $swoole_host = '127.0.0.1';
    protected static $swoole_port = '9502';

    protected static $_server;

    static protected $_process_pipe = array();
    static protected $forums = array();

    /**
     * @var $_config_set array swoole的初始化的配置
     * */
    static private $_config_set = array(
        'worker_num' => 4,       //设置启动的worker进程数
        'task_worker_num' => 4,  //配置的task进程的数量
        'task_ipc_mode' => 3,    //设置task进程和worker进程间的通信方式
        'daemonize' => 0,       //当设置为1的时候启动server就会转为后台守护进程进行运行
        'log_file' => '/data/log/swoole.log', //swoole的错误日志，运行期间的异常信息会记录到这里，开始守护进程后PHP代码中echo/var_dump/print的内容会写入该文件
    );

    /**
     * 启动服务
     */
    static public function start()
    {
        self::$_server = new swoole_server(self::$swoole_host, self::$swoole_port);
        self::$_server->set(self::$_config_set);

        if (self::$_server instanceof swoole_server) {
            self::$_server->on('Receive', array(__CLASS__, 'onReceive'));
            self::$_server->on('Task', function () {
            });
            self::$_server->on('Finish', function () {
            });
            self::$_server->start();
        } else {
            echo 'need new swoole_server first $_server is not a object';
        }
    }

    static public function onReceive(swoole_server $server, $fd, $from_id, $data)
    {
        $param = unserialize($data);
        $script_name = $param['script_name'];
        // 参数验证
        global $keys;
        if (!isset($keys[$script_name]) && $script_name != 'all') {
            exit('脚本参数错误');
        }
        switch ($script_name) {
            // 单个执行用户类的 都是50个表 启动50个进程跑
            case 'member':
            case 'member_profile':
            case 'member_count':
            case 'member_status':
            case 'member_field_home':
            case 'hash_user':
                self::member($script_name);
                break;

            case 'forum_post':
                self::post();
                break;

            // 跑主题时
            case 'forum_thread':
                self::forumThread();
                break;

            // 主题分页集合
            case 'thread_set':
                self::threadSet();
                break;
            // 总置顶的主题集合
            case 'thread_top':
                self::threadTop();
                break;

            default:
                break;
        }
    }



    /**
     * 导入主题页的帖子内容
     */
    static protected function post()
    {
        $obj = self::M('forum_post');
        $msg = date('Y-m-d H:i:s') . "=============forum_post===============开始\n";
        file_put_contents('log.txt', $msg, FILE_APPEND);

        // 启动50个进程跑如数据
        for ($i = 0; $i < 50; $i++) {
            $process = new swoole_process(function (swoole_process $process) use ($i, $obj) {
                $res = $obj->doPost($i); // 脚本儿最后返回的内容
                $process->write($res); // 回调时返回的内容写给主进程
            });
            $process->start();
            // 写入进程集合
            self::$_process_pipe[$process->pipe] = $process;
            swoole_event_add($process->pipe, array(__CLASS__, 'processPiPe'));
        }
    }

    /**
     * @param $script_name
     */
    static protected function member($script_name)
    {
        $obj = self::M($script_name);
        $msg = date('Y-m-d H:i:s') . '=============' . $script_name . "===============开始\n";
        file_put_contents('log.txt', $msg, FILE_APPEND);

        // 启动50个进程跑如数据
        for ($i = 0; $i < 50; $i++) {
            $process = new swoole_process(function (swoole_process $process) use ($i, $obj) {
                $res = $obj->into($i); // 脚本儿最后返回的内容
                $process->write($res); // 回调时返回的内容写给主进程
            });
            $process->start();
            // 写入进程集合
            self::$_process_pipe[$process->pipe] = $process;
            swoole_event_add($process->pipe, array(__CLASS__, 'processPiPe'));
        }


    }

    /**
     * 对主题单表启动了 10 个进程 每个进程跑15万条
     */
    static protected function forumThread()
    {
        $obj = self::M('forum_thread');

        $msg = date('Y-m-d H:i:s') . "=============forum_thread===============开始\n";
        file_put_contents('log.txt', $msg, FILE_APPEND);

        // 启动50个进程跑如数据
        $every = 150000;
        for ($i = 0; $i < 50; $i++) {
            $start = $i * $every;
            $end = $start + $every;
            $process = new swoole_process(function (swoole_process $process) use ($start, $end, $obj) {
                $res = $obj->into($start, $end); // 脚本儿最后返回的内容
                $process->write($res); // 回调时返回的内容写给主进程
            });
            $process->start();

            // 写入进程集合
            self::$_process_pipe[$process->pipe] = $process;
            swoole_event_add($process->pipe, array(__CLASS__, 'processPiPe'));
        }
    }

    /**
     * 对主题单表有序集合预热启动了 50 个进程 每个进程跑15万条
     */
    static protected function threadSet()
    {
        global $config;
        $db_mysqli = new db_mysqli();
        $link_dx = $db_mysqli->connect();


        $sql = "SELECT fid FROM ".$config['mysql']['db_prfix']."forum_forum WHERE status = '1'";
        $query = mysqli_query($link_dx, $sql);
        self::$forums = array();
        $redis_db1 = new Redis();
        $redis_db1->connect($config['redis_db1']['host'], $config['redis_db1']['port']);
        $redis_db1->del('forums');
        while ($f = mysqli_fetch_assoc($query)) {
            // 必须跑入板块id
            $redis_db1->sAdd('forums',$f['fid']);

            $redis_db1->del($f['fid'].'-lastpost');
            $redis_db1->del($f['fid'].'-dateline');
            $redis_db1->del($f['fid'].'-replies');
            $redis_db1->del($f['fid'].'-views');
            $redis_db1->del($f['fid'].'-lastpost-1');
            $redis_db1->del($f['fid'].'-dateline-1');
            $redis_db1->del($f['fid'].'-replies-1');
            $redis_db1->del($f['fid'].'-views-1');

            $redis_db1->del($f['fid'].'-lastpost-2');
            $redis_db1->del($f['fid'].'-dateline-2');
            $redis_db1->del($f['fid'].'-replies-2');
            $redis_db1->del($f['fid'].'-views-2');

            $redis_db1->del($f['fid'].'-lastpost-3');
            $redis_db1->del($f['fid'].'-dateline-3');
            $redis_db1->del($f['fid'].'-replies-3');
            $redis_db1->del($f['fid'].'-views-3');

            $redis_db1->del($f['fid'].'-lastpost-4');
            $redis_db1->del($f['fid'].'-dateline-4');
            $redis_db1->del($f['fid'].'-replies-4');
            $redis_db1->del($f['fid'].'-views-4');
            $redis_db1->del($f['fid'].'-lastpost-5');
            $redis_db1->del($f['fid'].'-dateline-5');
            $redis_db1->del($f['fid'].'-replies-5');
            $redis_db1->del($f['fid'].'-views-5');

            self::$forums[] = $f['fid'];
        }

        $obj = self::M('thread_set');

        $msg = date('Y-m-d H:i:s') . "=============thread_set===============开始\n";
        file_put_contents('log.txt', $msg, FILE_APPEND);
        $fids = self::$forums;
        $fids = array_chunk($fids, 10);
        $count = count($fids);
        // 启动50个进程跑如数据
        for ($i = 0; $i < $count; $i++) {
            $fid = $fids[$i];
            $process = new swoole_process(function (swoole_process $process) use ($fid, $obj) {
                $res = $obj->doSet($fid); // 脚本儿最后返回的内容
                $process->write($res); // 回调时返回的内容写给主进程
            });
            $process->start();

            // 写入进程集合
            self::$_process_pipe[$process->pipe] = $process;
            swoole_event_add($process->pipe, array(__CLASS__, 'processPiPe'));
        }
    }

    /**
     *
     */
    static protected function threadTop()
    {
        $msg = date('Y-m-d H:i:s') . "=============thread_set===============开始\n";
        file_put_contents('log.txt', $msg, FILE_APPEND);

        $obj = self::M('thread_top');
        $obj->doTop();

        $msg = date('Y-m-d H:i:s') . "=============thread_set===============结束\n";
        file_put_contents('log.txt', $msg, FILE_APPEND);
    }




    /**
     * 进程回收写入日志
     *
     * @param $pipe
     */
    static public function processPiPe($pipe)
    {
        $worker = self::$_process_pipe[$pipe];
        $data = $worker->read();
        $worker->wait();
        unset(self::$_process_pipe[$pipe]);
        file_put_contents('log.txt', $data, FILE_APPEND);
        if (count(self::$_process_pipe) == 0) {
            $msg = date('Y-m-d H:i:s') . "==============结束==============\n";
            file_put_contents('log.txt', $msg, FILE_APPEND);
        }

    }

    /**
     * 实例化要跑的脚本类
     * @param $name 脚本类名字
     * @return mixed 实例化后的对象
     */
    static protected function M($name)
    {
        require_once 'script/' . $name . '.php';
        return new $name();
    }
}

hotServer::start();

